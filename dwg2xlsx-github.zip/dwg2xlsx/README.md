# DWG/DXF/PDF → Excel (Fire Alarm Address List)

Công cụ chuyển bản vẽ sơ đồ hệ thống báo cháy sang file Excel theo mẫu Address List (sheet LoopMx detectors).

## Hai cách dùng
**1. Bản web** (docs/index.html): đọc PDF và DXF ngay trên trình duyệt, không cần cài đặt.
Bật GitHub Pages (Settings → Pages → branch main, thư mục /docs) để có đường dẫn công khai.

**2. Bản Python** (src/dwg2xlsx.py): đọc được cả DWG.

    pip install -r requirements.txt
    python src/dwg2xlsx.py                 # giao diện chọn file
    python src/dwg2xlsx.py ban_ve.pdf      # dòng lệnh, ra ban_ve.xlsx

Đọc DWG cần cài thêm ODA File Converter (opendesign.com) hoặc LibreDWG.

## Quy tắc điền
Central = 1; Card = Loop + 10; Zone = Loop; Logical = Physical; DSCI = 1 (0 nếu "Any type");
Sensitivity = Normal sensitivity; mô tả tối đa 37 ký tự. Chỉnh trong src/config.json.

## Giới hạn
Nhận dạng theo text là suy đoán, hãy đối chiếu với file _kiemtra.xlsx. PDF dạng ảnh quét cần OCR (chưa hỗ trợ).

## Bản quyền
© 2026 [TÊN CỦA BẠN]. All rights reserved. Xem file LICENSE.
