#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) 2026 [TÊN CỦA BẠN]. All rights reserved.
"""
DWG -> Excel (theo mẫu Fire Alarm System Address List)

  python dwg2xlsx.py                  -> mở giao diện, chọn DWG là xong
  python dwg2xlsx.py ban_ve.pdf|.dwg  -> xuất ban_ve.xlsx (+ ban_ve_kiemtra.xlsx để đối chiếu)

Cần:  pip install ezdxf openpyxl pdfplumber
DWG là định dạng đóng nên cần thêm MỘT trong hai bộ chuyển đổi (miễn phí):
  - ODA File Converter  (opendesign.com/guestfiles/oda_file_converter)
  - LibreDWG (lệnh dwg2dxf)
Nếu đã có file .dxf thì không cần bộ chuyển đổi.
"""
import argparse, glob, json, os, re, shutil, subprocess, sys, tempfile
from collections import Counter, defaultdict
from copy import copy

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG = os.path.join(HERE, "config.json")


# ───────────────────────── 1. DWG → DXF ─────────────────────────
def find_converter(cfg):
    p = cfg.get("oda_converter_path") or os.environ.get("ODA_CONVERTER")
    if p and os.path.exists(p):
        return "oda", p
    p = shutil.which("ODAFileConverter")
    if p:
        return "oda", p
    for pat in (r"C:\Program Files\ODA\ODAFileConverter*\ODAFileConverter.exe",
                r"C:\Program Files (x86)\ODA\ODAFileConverter*\ODAFileConverter.exe",
                "/usr/bin/ODAFileConverter", "/opt/ODAFileConverter*/ODAFileConverter"):
        hit = sorted(glob.glob(pat))
        if hit:
            return "oda", hit[-1]
    p = shutil.which("dwg2dxf")
    if p:
        return "libredwg", p
    return None, None


def to_dxf(path, cfg, log):
    """Trả về đường dẫn DXF (chuyển đổi nếu đầu vào là DWG)."""
    if path.lower().endswith(".dxf"):
        return path, None
    kind, exe = find_converter(cfg)
    if not kind:
        raise RuntimeError(
            "Không tìm thấy bộ chuyển DWG→DXF. Hãy cài ODA File Converter hoặc LibreDWG "
            "(hoặc tự lưu bản vẽ sang DXF bằng AutoCAD rồi chọn file .dxf).")
    tmp = tempfile.mkdtemp(prefix="dwg2xlsx_")
    src, dst = os.path.join(tmp, "in"), os.path.join(tmp, "out")
    os.makedirs(src); os.makedirs(dst)
    name = os.path.basename(path)
    shutil.copy(path, os.path.join(src, name))
    log(f"Đang chuyển DWG → DXF bằng {kind}: {exe}")
    if kind == "oda":
        cmd = [exe, src, dst, "ACAD2018", "DXF", "0", "1", "*.DWG"]
    else:
        cmd = [exe, "-y", "-o", os.path.join(dst, os.path.splitext(name)[0] + ".dxf"),
               os.path.join(src, name)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = glob.glob(os.path.join(dst, "*.dxf")) + glob.glob(os.path.join(dst, "*.DXF"))
    if not out:
        raise RuntimeError(f"Chuyển đổi thất bại.\n{r.stdout}\n{r.stderr}")
    return out[0], tmp


# ───────────────────────── 2. Đọc DXF ─────────────────────────
def read_drawing(dxf_path):
    """Trả về (inserts, texts). texts đã làm phẳng block lồng nhau, toạ độ thật."""
    import ezdxf
    doc = ezdxf.readfile(dxf_path)
    inserts, texts = [], []

    def add_text(e, layer=None):
        t = e.dxftype()
        try:
            p = e.dxf.insert
            s_ = e.plain_text() if t == "MTEXT" else e.dxf.text
        except Exception:
            return
        s_ = (s_ or "").replace("\n", " ").strip()
        if s_:
            texts.append({"layer": layer or e.dxf.layer, "x": round(p.x, 2), "y": round(p.y, 2), "text": s_})

    def walk(entities, depth, top):
        for e in entities:
            t = e.dxftype()
            if t in ("TEXT", "MTEXT"):
                add_text(e)
            elif t == "INSERT":
                if top:
                    p = e.dxf.insert
                    inserts.append({"block": e.dxf.name, "layer": e.dxf.layer,
                                    "x": round(p.x, 2), "y": round(p.y, 2),
                                    "attribs": {a.dxf.tag.strip(): (a.dxf.text or "").strip() for a in e.attribs}})
                for a in e.attribs:
                    add_text(a, e.dxf.layer)
                if depth < 3:
                    try:
                        walk(list(e.virtual_entities()), depth + 1, False)
                    except Exception:
                        pass

    walk(doc.modelspace(), 0, True)
    return inserts, texts


# ───────────────────────── 2b. Đọc PDF ─────────────────────────
def read_pdf(path):
    """Trả về (texts, tables). texts có toạ độ (y hướng lên) và số trang."""
    import pdfplumber
    texts, tables = [], []
    with pdfplumber.open(path) as pdf:
        for pi, page in enumerate(pdf.pages):
            for w in page.extract_words(keep_blank_chars=True, x_tolerance=2, y_tolerance=2):
                t = w["text"].strip()
                if t:
                    texts.append({"layer": f"page{pi + 1}", "page": pi, "x": round(w["x0"], 1),
                                  "y": round(-w["top"], 1), "text": t})
            try:
                for tb in page.extract_tables():
                    tables.append([[(c or "").replace("\n", " ").strip() for c in r] for r in tb])
            except Exception:
                pass
    return texts, tables


HDR = {"loop": ["loop"], "addr": ["address", "addr", "địa chỉ", "dia chi", "device no", "no."],
       "zone": ["zone", "khu"], "type": ["type", "loại", "loai", "device"],
       "d1": ["description", "desc", "location", "name", "room", "mô tả", "vị trí"]}


def build_rows_from_tables(tables, cfg, log):
    rows = []
    for tb in tables:
        if not tb: continue
        # 1) có hàng tiêu đề rõ ràng: loop + address ở 2 cột riêng
        col, start = {}, 0
        for ri, r in enumerate(tb[:3]):
            cand = {}
            for ci, c in enumerate(r):
                for key, words in HDR.items():
                    if key not in cand and any(w in c.lower() for w in words) and c:
                        cand[key] = ci
            if "addr" in cand and ("loop" in cand or len(cand) >= 3):
                col, start = cand, ri + 1; break
        for r in tb[start:]:
            r = [c.strip() for c in r]
            loop = addr = card = None
            if col:
                get = lambda k: r[col[k]] if k in col and col[k] < len(r) else ""
                m = ADDR_RX.match(get("addr"))
                try:
                    if "loop" in col and get("loop").isdigit() and get("addr").isdigit():
                        loop, addr = int(get("loop")), int(get("addr"))
                    elif m:
                        loop, addr = int(m["loop"]), int(m["addr"]); card = int(m["card"]) if m["card"] else None
                except (TypeError, ValueError): pass
                if loop is None: continue
                used = {col[k] for k in col}
                rest = [c for i, c in enumerate(r) if i not in used and c]
                d1 = get("d1") or (rest.pop(0) if rest else "")
                d2 = rest[0] if rest else ""
                typ_txt, zone = get("type"), get("zone")
            else:
                hit = next((ADDR_RX.match(c) for c in r if ADDR_RX.match(c)), None)
                if not hit: continue
                loop, addr = int(hit["loop"]), int(hit["addr"]); card = int(hit["card"]) if hit["card"] else None
                rest = [c for c in r if c and not ADDR_RX.match(c)]
                d1, d2, typ_txt, zone = (rest + ["", ""])[0], (rest + ["", ""])[1], "", ""
            rows.append({"central": cfg["central_address"], "card": card or loop + cfg["card_offset"],
                         "loop": loop, "zone": int(zone) if str(zone).isdigit() else loop, "addr": addr,
                         "type": map_type("", typ_txt, cfg) if typ_txt else cfg["default_type"],
                         "d1": d1, "d2": d2})
    if rows: log(f"Đọc từ bảng trong PDF: {len(rows)} dòng.")
    rows.sort(key=lambda r: (r["card"], r["loop"], r["addr"]))
    return rows


# ───────────────────────── 3. Inspect ─────────────────────────
def write_inspect(inserts, texts, out_path):
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active; ws.title = "Blocks"
    ws.append(["Tên block", "Số lượng", "Có attribute?", "Các tag attribute", "Ví dụ giá trị"])
    by = defaultdict(list)
    for i in inserts: by[i["block"]].append(i)
    for name, lst in sorted(by.items(), key=lambda kv: -len(kv[1])):
        tags = sorted({t for i in lst for t in i["attribs"]})
        ex = next((i["attribs"] for i in lst if i["attribs"]), {})
        ws.append([name, len(lst), "có" if tags else "không", ", ".join(tags),
                   "; ".join(f"{k}={v}" for k, v in ex.items())])
    ws2 = wb.create_sheet("Inserts")
    ws2.append(["Block", "Layer", "X", "Y", "Attributes"])
    for i in inserts:
        ws2.append([i["block"], i["layer"], i["x"], i["y"],
                    "; ".join(f"{k}={v}" for k, v in i["attribs"].items())])
    ws3 = wb.create_sheet("Texts")
    ws3.append(["Layer", "X", "Y", "Nội dung"])
    for t in texts: ws3.append([t["layer"], t["x"], t["y"], t["text"]])
    ws4 = wb.create_sheet("Layers")
    ws4.append(["Layer", "Số block", "Số text"])
    c1 = Counter(i["layer"] for i in inserts); c2 = Counter(t["layer"] for t in texts)
    for l in sorted(set(c1) | set(c2)): ws4.append([l, c1[l], c2[l]])
    for w in wb:
        for c in w[1]: c.font = Font(bold=True)
        w.freeze_panes = "A2"
        for col in w.columns:
            w.column_dimensions[col[0].column_letter].width = min(60, max(10, max(len(str(c.value or "")) for c in col[:200]) + 2))
    wb.save(out_path)


# ───────────────────────── 4. Ánh xạ → dòng Excel ─────────────────────────
def pick(attribs, names):
    up = {k.upper(): v for k, v in attribs.items()}
    for n in names:
        if up.get(n.upper()):
            return up[n.upper()]
    return ""


def map_type(block, type_attr, cfg):
    key = (type_attr or block).upper()
    for needle, target in cfg["type_map"]:
        if needle.upper() in key or needle.upper() in block.upper():
            return target
    return cfg["default_type"]


def build_rows(inserts, cfg, log):
    am, rx = cfg["attribute_map"], re.compile(cfg["address_regex"])
    ignore = [re.compile(p, re.I) for p in cfg["ignore_blocks"]]
    rows, skipped = [], 0
    for ins in inserts:
        if any(r.search(ins["block"]) for r in ignore) or not ins["attribs"]:
            continue
        a = ins["attribs"]
        loop = pick(a, am["loop"]); card = pick(a, am["card"]); addr = pick(a, am["address"])
        m = rx.match(addr.strip()) if addr else None
        if m:
            g = m.groupdict()
            card = card or g.get("card") or ""; loop = loop or g.get("loop") or ""; addr = g.get("addr")
        try:
            loop_i, addr_i = int(loop), int(addr)
        except (TypeError, ValueError):
            skipped += 1
            log(f"  ! Bỏ qua block '{ins['block']}' tại ({ins['x']},{ins['y']}): "
                f"không đọc được địa chỉ từ {a}")
            continue
        card_i = int(card) if str(card).isdigit() else loop_i + cfg["card_offset"]
        zone = pick(a, am["zone"])
        zone_i = int(zone) if str(zone).isdigit() else (loop_i if cfg["zone_default"] == "loop" else "")
        rows.append({
            "central": cfg["central_address"], "card": card_i, "loop": loop_i, "zone": zone_i,
            "addr": addr_i,
            "type": map_type(ins["block"], pick(a, am["type"]), cfg),
            "d1": pick(a, am["desc1"]), "d2": pick(a, am["desc2"]),
        })
    rows.sort(key=lambda r: (r["card"], r["loop"], r["addr"]))
    if skipped: log(f"Bỏ qua {skipped} block do thiếu/sai địa chỉ.")
    return rows


ADDR_RX = re.compile(r"^[A-Za-z]{0,3}\s?(?:(?P<card>\d{1,2})\s*[-/.:]\s*)?(?P<loop>\d{1,2})\s*[-/.:]\s*(?P<addr>\d{1,3})$")


def build_rows_from_text(texts, cfg, log):
    """Suy đoán: text dạng 'loop-địa chỉ' là thiết bị; mô tả = text gần nhất."""
    import math
    addr, other = [], []
    for t in texts:
        m = ADDR_RX.match(t["text"].strip())
        (addr if m else other).append((t, m))
    if not addr:
        return []
    log(f"Chế độ suy đoán từ text: thấy {len(addr)} nhãn địa chỉ. Cần kiểm tra lại kết quả.")
    others = [o for o, _ in other if 2 <= len(o["text"]) <= 60 and not o["text"].replace(".", "").isdigit()]
    rows, used = [], set()
    for t, m in addr:
        g = m.groupdict()
        loop_i, addr_i = int(g["loop"]), int(g["addr"])
        card_i = int(g["card"]) if g.get("card") else loop_i + cfg["card_offset"]
        near = sorted([o for o in others if o.get("page", 0) == t.get("page", 0)], key=lambda o: math.hypot(o["x"] - t["x"], o["y"] - t["y"]))
        near = [o for o in near if id(o) not in used][:2]
        for o in near: used.add(id(o))
        d = [o["text"] for o in near] + ["", ""]
        rows.append({"central": cfg["central_address"], "card": card_i, "loop": loop_i, "zone": loop_i,
                     "addr": addr_i, "type": cfg["default_type"], "d1": d[0], "d2": d[1]})
    rows.sort(key=lambda r: (r["card"], r["loop"], r["addr"]))
    return rows


# ───────────────────────── 5. Ghi vào file mẫu ─────────────────────────
def write_excel(rows, template, out_path, cfg, log):
    from openpyxl import load_workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    import warnings; warnings.filterwarnings("ignore")
    wb = load_workbook(template)
    ws = wb[cfg["sheet"]]
    r0 = cfg["first_row"]
    allowed = {str(c.value) for c in wb["LoopMx Detector types"]["A"][3:55] if c.value}
    ncol = 21
    style = [ws.cell(r0, c)._style for c in range(1, ncol + 1)]
    for row in ws.iter_rows(min_row=r0, max_row=max(ws.max_row, r0), max_col=ncol):
        for c in row: c.value = None

    seen, warns = set(), 0
    for i, r in enumerate(rows):
        n = r0 + i
        key = (r["card"], r["loop"], r["addr"])
        if key in seen: log(f"  ! Trùng địa chỉ {key}"); warns += 1
        seen.add(key)
        if r["type"] not in allowed:
            log(f"  ! Loại thiết bị '{r['type']}' không có trong danh sách của mẫu"); warns += 1
        for k in ("d1", "d2"):
            if len(r[k]) > 37:
                log(f"  ! Mô tả quá 37 ký tự, đã cắt: '{r[k]}'"); r[k] = r[k][:37]; warns += 1
        vals = {"A": r["central"], "B": r["card"], "C": r["loop"], "D": r["zone"],
                "E": r["addr"], "F": r["addr"], "G": r["type"],
                "H": 0 if r["type"] in cfg["dsci_enabled_except_types"] else 1,
                "I": r["d1"], "J": r["d2"]}
        vals.update(cfg["defaults"])
        for letter, v in vals.items():
            ws[f"{letter}{n}"] = v
        for c in range(1, ncol + 1):
            ws.cell(n, c)._style = copy(style[c - 1])

    last = max(r0 + len(rows) - 1, r0)
    # openpyxl làm mất dropdown dạng x14 của mẫu → tạo lại dropdown chuẩn
    def dv(formula, rng):
        d = DataValidation(type="list", formula1=formula, allow_blank=True); ws.add_data_validation(d)
        for part in rng.split(): d.add(part)
    dv("'LoopMx Detector types'!$A$4:$A$55", f"G{r0}:G{last + 50}")
    dv("'LoopMx Detector types'!$P$4:$P$9", f"K{r0}:K{last + 50}")
    dv("'LoopMx Detector types'!$Q$4:$Q$8", f"T{r0}:T{last + 50}")
    dv("'CsLoopM Detector types'!$H$4:$H$5", f"H{r0}:H{last + 50} L{r0}:S{last + 50} U{r0}:U{last + 50}")
    wb.save(out_path)
    log(f"Đã ghi {len(rows)} thiết bị vào '{cfg['sheet']}' → {out_path}  ({warns} cảnh báo)")


# ───────────────────────── 6. Điều phối ─────────────────────────
def load_cfg(path=None):
    with open(path or DEFAULT_CONFIG, encoding="utf-8") as f:
        return json.load(f)


def run_inspect(src, out, cfg, log=print):
    dxf, tmp = to_dxf(src, cfg, log)
    try:
        ins, tx = read_drawing(dxf)
        write_inspect(ins, tx, out)
        log(f"Tìm thấy {len(ins)} block, {len(tx)} text → {out}")
    finally:
        if tmp: shutil.rmtree(tmp, ignore_errors=True)


def run_export(src, template, out, cfg, log=print):
    template = template or os.path.join(HERE, "template.xlsx")
    out = out or os.path.splitext(src)[0] + ".xlsx"
    is_pdf = src.lower().endswith(".pdf")
    dxf, tmp = (None, None) if is_pdf else to_dxf(src, cfg, log)
    try:
        if is_pdf:
            texts, tables = read_pdf(src); ins = []
            log(f"Đọc được {len(texts)} đoạn text, {len(tables)} bảng.")
            rows = build_rows_from_tables(tables, cfg, log)
        else:
            ins, texts = read_drawing(dxf)
            log(f"Đọc được {len(ins)} block, {len(texts)} text.")
            rows = build_rows(ins, cfg, log)
        if not rows:
            rows = build_rows_from_text(texts, cfg, log)
        raw = os.path.splitext(out)[0] + "_kiemtra.xlsx"
        write_inspect(ins, texts, raw)
        log(f"File dữ liệu thô để đối chiếu: {raw}")
        if not rows:
            raise RuntimeError("Không nhận dạng được thiết bị nào trong bản vẽ. "
                               f"Hãy gửi file {os.path.basename(raw)} để chỉnh bộ nhận dạng.")
        write_excel(rows, template, out, cfg, log)
        return out
    finally:
        if tmp: shutil.rmtree(tmp, ignore_errors=True)


# ───────────────────────── 7. Giao diện ─────────────────────────
def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
    root = tk.Tk(); root.title("DWG → Excel (Fire Alarm Address List)"); root.geometry("720x460")
    box = scrolledtext.ScrolledText(root, height=20)
    def log(s): box.insert("end", str(s) + "\n"); box.see("end"); root.update_idletasks()
    def go():
        files = filedialog.askopenfilenames(filetypes=[("DWG/DXF/PDF", "*.dwg *.dxf *.pdf")])
        cfg = load_cfg()
        for f in files:
            log(f"=== {os.path.basename(f)}")
            try: log(f"Xong → {run_export(f, None, None, cfg, log)}")
            except Exception as e: log(f"LỖI: {e}"); messagebox.showerror("Lỗi", str(e))
    ttk.Button(root, text="Chọn file DWG/DXF/PDF và xuất Excel…", command=go).pack(pady=10)
    box.pack(fill="both", expand=True, padx=8, pady=8)
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*", help="một hoặc nhiều file .dwg/.dxf/.pdf")
    ap.add_argument("-o", "--output", help="file Excel xuất ra (mặc định: cùng tên, cạnh file DWG)")
    ap.add_argument("-t", "--template", help="file Excel mẫu (mặc định: template.xlsx đi kèm)")
    ap.add_argument("-c", "--config", default=DEFAULT_CONFIG)
    args = ap.parse_args()
    if not args.files: return gui()
    cfg = load_cfg(args.config)
    for f in args.files:
        run_export(f, args.template, args.output if len(args.files) == 1 else None, cfg)


if __name__ == "__main__":
    main()
